﻿/* Purpose: Calculate the BMI
 * Input : Height and Weight
 * Output: The BMI of person
 * Author: Kashish Sharma
 * Last modified : 1999.11.25
 */ 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPSC1012_Kashish_Sharma
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare variables:
            double Weight, Height, BMI;
            string userInput;

            Console.WriteLine("The weight of a person in pounds is ");
            userInput = Console.ReadLine();
            Weight = double.Parse(userInput);

            Console.WriteLine("The height of a person in inches is ");
            userInput = Console.ReadLine();
            Height = double.Parse(userInput);

            Console.WriteLine("You enterd {0}and {1}", Weight, Height);
            BMI = 703 * Weight / Math.Pow(Height, 2);

            //outputing the values:
            Console.WriteLine("703* {0} / {1}= {2}" , Weight, Height, Math.Round(BMI, 2));

            Console.ReadLine();
        }
    }
}

            



            
            





        
    

